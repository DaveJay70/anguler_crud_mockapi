export class Faculty {
    id:number=0;
    FacultyName:string='';
    FacultyImage:string='';
    FacultyDesignation:string='';
    FacultyEducationQualification:string='';
    FacultyExperience:string='';
    FacultyWorkingSince:string='';

}
